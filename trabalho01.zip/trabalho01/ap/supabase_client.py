from dotenv import load_dotenv 
from supabase import create_client 
import os 

load_dotenv()   

SUPABASE_URL = os.getenv("SUPABASE_URL") 
SUPABASE_KEY = os.getenv("SUPABASE_KEY")   

if not SUPABASE_URL or not SUPABASE_KEY: 
    raise RuntimeError("Configure SUPABASE_URL e SUPABASE_KEY no arquivo .env") 

supabase = create_client(SUPABASE_URL, SUPABASE_KEY,) 